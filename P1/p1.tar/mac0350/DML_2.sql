-- NascidoEm --
INSERT INTO NascidoEm VALUES ('Pedro', 'Marte');
INSERT INTO NascidoEM VALUES ('Luis', 'Venus');
INSERT INTO NascidoEM VALUES ('Matheus', 'Jupiter');
INSERT INTO NascidoEM VALUES ('Homero', 'Jupiter');
INSERT INTO NascidoEM VALUES ('Roberto', 'Venus');
INSERT INTO NascidoEM VALUES ('Felipe', 'Mercurio');
INSERT INTO NascidoEM VALUES ('Luisa', 'Jupiter');
INSERT INTO NascidoEM VALUES ('Igor', 'Marte');

-- ExisteEm --
INSERT INTO ExisteEm VALUES ('Rosa', 'Jupiter');
INSERT INTO ExisteEm VALUES ('Orquidea', 'Jupiter');
INSERT INTO ExisteEm VALUES ('Tulipa', 'Venus');
INSERT INTO ExisteEm VALUES ('Lirio', 'Mercurio');
INSERT INTO ExisteEm VALUES ('Begonia', 'Marte');
INSERT INTO ExisteEm VALUES ('Calendula', 'Mercurio');
INSERT INTO ExisteEm VALUES ('Lavanda', 'Jupiter');
INSERT INTO ExisteEm VALUES ('Amarilis', 'Venus');

-- AlergicoA --
INSERT INTO AlergicoA VALUES ('Pedro', 'Rosa');
INSERT INTO AlergicoA VALUES ('Pedro', 'Tulipa');
INSERT INTO AlergicoA VALUES ('Luis', 'Rosa');
INSERT INTO AlergicoA VALUES ('Matheus', 'Lirio');
INSERT INTO AlergicoA VALUES ('Matheus', 'Orquidea');
INSERT INTO AlergicoA VALUES ('Matheus', 'Begonia');
INSERT INTO AlergicoA VALUES ('Roberto', 'Orquidea');
INSERT INTO AlergicoA VALUES ('Roberto', 'Lavanda');
INSERT INTO AlergicoA VALUES ('Felipe', 'Tulipa');
INSERT INTO AlergicoA VALUES ('Felipe', 'Orquidea');
INSERT INTO AlergicoA VALUES ('Felipe', 'Calendula');
INSERT INTO AlergicoA VALUES ('Felipe', 'Amarilis');
INSERT INTO AlergicoA VALUES ('Luisa', 'Lirio');
INSERT INTO AlergicoA VALUES ('Luisa', 'Calendula');
INSERT INTO AlergicoA VALUES ('Homero', 'Rosa');
INSERT INTO AlergicoA VALUES ('Homero', 'Tulipa');
INSERT INTO AlergicoA VALUES ('Homero', 'Lirio');
INSERT INTO AlergicoA VALUES ('Homero', 'Lavanda');
INSERT INTO AlergicoA VALUES ('Igor', 'Tulipa');
INSERT INTO AlergicoA VALUES ('Igor', 'Lirio');
INSERT INTO AlergicoA VALUES ('Igor', 'Begonia');
INSERT INTO AlergicoA VALUES ('Igor', 'Lavanda');
INSERT INTO AlergicoA VALUES ('Igor', 'Amarilis');