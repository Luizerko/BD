#!/bin/bash

python3 cria_pessoas.py;

python3 adiciona_pessoas.py;

python3 adiciona_relacao.py;
